# X4G VPN — Android Client

A native Android VPN client (Kotlin + Jetpack Compose) built around the
**sing-box** core, styled after professional clients like Hiddify Next.
The app ships with one built-in connection — the user only ever sees
Connect / Disconnect, live status, and ping. No config, UUID, server
address, or link is ever shown in the UI.

## What's included

- Full Gradle project (Kotlin DSL), Android Studio–ready
- Jetpack Compose UI: single-screen home with animated connect button,
  live status label, ping + server metric card, dark theme throughout
- `VpnService`-based foreground service (`X4GVpnService`) that drives the
  sing-box `libbox` core, establishes the TUN interface, and keeps a
  persistent status notification while connected
- VLESS URI parser + sing-box JSON config builder
  (`VlessConfigBuilder.kt`)
- The default connection is embedded **obfuscated** (XOR + Base64) in
  `ConfigVault.kt`, not as a plaintext string in source — see the security
  note below for what this does and doesn't protect against
- ProGuard/R8 rules, adaptive launcher icon, manifest, all resources

## Two things you must do before this builds into an APK

### 1. Add the sing-box core binary (`libbox.aar`)
sing-box's Android bindings are a compiled Go Mobile library — a binary
that can't be produced from source text alone. Full instructions are in
`app/libs/README.md`. Short version: download `libbox.aar` from the
sing-box project and drop it into `app/libs/`.

### 2. Generate the Gradle wrapper jar
See `gradle/wrapper/README_WRAPPER_JAR.md` — opening the project in
Android Studio does this automatically on first sync.

Once both are in place:

```bash
./gradlew assembleRelease
```

produces `app/build/outputs/apk/release/app-release-unsigned.apk`. Sign it
with your own keystore (fill in `signingConfigs.release` in
`app/build.gradle.kts`, or sign manually with `apksigner`) to get an
installable release APK.

## Rebranding

- App name: `app/src/main/res/values/strings.xml` → `app_name`
- App icon: `app/src/main/res/drawable/ic_launcher_foreground.xml` and
  `ic_launcher_background.xml` (vector, easy to restyle), or replace with
  your own PNG mipmaps
- Package/applicationId: `com.x4g.vpn` in `app/build.gradle.kts` and the
  Kotlin package folders under `app/src/main/java/com/x4g/vpn/`
- Accent color: `app/src/main/java/com/x4g/vpn/ui/theme/Color.kt`
  (`AccentGreen`)

## Changing the built-in server later

Don't hand-edit the obfuscated string in `ConfigVault.kt`. Instead, take
your new `vless://...` URI and re-run the same XOR+Base64 scheme (a short
Python snippet is enough — the key bytes are the two arrays at the top of
`ConfigVault.kt`), then replace the `PAYLOAD` constant.

## Security note (read this)

The embedded config is **obfuscated, not encrypted with a secret only you
hold** — the app has to decode it locally to connect, so the XOR key ships
inside the same APK. This stops a casual look at the decompiled strings or
a `strings app.apk` grep from immediately showing your UUID and server
address (which is what the "never show config" requirement in this project
is about), but it will not stop a motivated person with a decompiler from
recovering it, the same way it wouldn't for any other consumer VPN app
with a bundled default server. If that server is meant to be genuinely
private, keep an eye on its usage/bandwidth regardless.

## Project structure

```
app/src/main/java/com/x4g/vpn/
├── X4GApplication.kt
├── core/
│   ├── VlessConfigBuilder.kt   # VLESS URI -> sing-box JSON
│   ├── SingBoxController.kt    # libbox lifecycle wrapper
│   └── PingChecker.kt          # TCP handshake latency measurement
├── data/
│   ├── ConfigVault.kt          # obfuscated embedded config
│   ├── ConnectionState.kt      # state enum + UI state model
│   └── VpnStateRepository.kt   # process-wide StateFlow
├── service/
│   └── X4GVpnService.kt        # VpnService: TUN + libbox + notification
└── ui/
    ├── MainActivity.kt
    ├── MainViewModel.kt
    ├── screens/                # HomeScreen, ConnectButton, StatusComponents
    └── theme/                  # Color, Theme, Type
```
