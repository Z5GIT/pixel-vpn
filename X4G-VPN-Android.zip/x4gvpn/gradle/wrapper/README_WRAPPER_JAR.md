This directory needs a `gradle-wrapper.jar` binary, which is a compiled Java
class file distributed by Gradle. It cannot be generated from source text in
this environment (no network access to fetch it, and it isn't meaningfully
representable as source).

You have two easy ways to get it — pick either one, both take a few seconds:

## Option A (recommended): let Android Studio generate it
Just open this project folder in Android Studio. On first open it detects
the wrapper is incomplete and offers to regenerate it automatically, or:
File > Sync Project with Gradle Files will do it.

## Option B: command line, if you have Gradle installed locally
From the project root:
```bash
gradle wrapper --gradle-version 8.7
```
This creates `gradle/wrapper/gradle-wrapper.jar` matching the
`gradle-wrapper.properties` already included in this project.

Everything else (`gradlew`, `gradlew.bat`, `gradle-wrapper.properties`) is
already in place and correctly configured for Gradle 8.7.
