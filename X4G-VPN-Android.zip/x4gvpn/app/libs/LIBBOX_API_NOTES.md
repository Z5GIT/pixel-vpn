# libbox API surface used by this project

This project's Kotlin code (`SingBoxController.kt`, `X4GVpnService.kt`)
calls into the following `io.nekohasekai.libbox` classes/interfaces, which
come from sing-box's official Go Mobile bindings:

- `Libbox.setup(basePath, workingPath, tempPath, isTVOS)`
- `Libbox.newService(configJson, platformInterface): BoxService`
- `BoxService.start()`, `BoxService.close()`
- `PlatformInterface` (implemented in `X4GVpnService`):
  `openTun`, `useProcFs`, `findConnectionOwner`, `packageNameByUid`,
  `uidByPackageName`, `usePlatformAutoDetectInterfaceControl`,
  `autoDetectInterfaceControl`, `underNetworkExtension`,
  `includeAllNetworks`, `clearDNSCache`, `readWIFIState`,
  `systemCertificates`, `startDefaultInterfaceMonitor`,
  `closeDefaultInterfaceMonitor`, `getInterfaces`,
  `usePlatformDefaultInterfaceMonitor`, `usePlatformInterfaceGetter`
- `TunOptions`, `InterfaceUpdateListener`, `NetworkInterfaceIterator`,
  `WIFIState`, `StringIterator`

This mirrors the public interface sing-box publishes for its official
Android client (`SagerNet/sing-box-for-android`), so once you drop a real
`libbox.aar` into `app/libs/` (see `README.md` in this folder), these calls
resolve as-is with no further code changes required.

If the exact method signatures differ slightly between sing-box versions
(the project evolves), diff against the `PlatformInterface.java` /
`libbox.aar`'s decompiled interface for the version you download, and adjust
the `object : PlatformInterface { ... }` block in `X4GVpnService.kt`
accordingly — everything else (config building, UI, service lifecycle) is
independent of that surface.
