# sing-box core (libbox.aar)

This project uses **sing-box** as its VPN engine, via its official Go Mobile
bindings (`libbox`). Because that binary must be compiled from Go source for
Android (arm64-v8a / armeabi-v7a / x86_64), it cannot be produced inside a
sandboxed environment without network/NDK access — you need to build or
download it once, locally, before the app will compile.

## Option A — download a prebuilt AAR (fastest)

1. Go to https://github.com/SagerNet/sing-box/releases
2. Find a release that ships `libbox.aar` (or use the `sing-box-android` /
   `libbox` artifacts from the sing-box-related client projects such as
   `SagerNet/sing-box-for-android`, which publish prebuilt `libbox.aar`).
3. Download `libbox.aar` and place it here as:
   `app/libs/libbox.aar`

## Option B — build it yourself from source

Requirements: Go 1.21+, Android NDK, `gomobile`.

```bash
git clone https://github.com/SagerNet/sing-box.git
cd sing-box
go install golang.org/x/mobile/cmd/gomobile@latest
gomobile init
make lib_android
# Produces build/libbox.aar
cp build/libbox.aar /path/to/X4G-VPN/app/libs/libbox.aar
```

## After placing the AAR

The app module already references it via:

```kotlin
implementation(files("libs/libbox.aar"))
```

No further Gradle changes are needed. Sync the project and build.

## Why this can't be automated here

`libbox.aar` bundles compiled Go/C code for multiple ABIs and is typically
tens of MB — building it requires the Go toolchain + Android NDK + network
access, none of which are available in this generation environment. Every
other part of this project (Kotlin app code, UI, service, manifest, Gradle
config) is complete and does not require any manual editing — only this one
binary dependency needs to be dropped in locally.
