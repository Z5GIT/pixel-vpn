# X4G VPN — ProGuard / R8 rules

# Keep sing-box Go Mobile bindings (JNI/reflection boundary)
-keep class io.nekohasekai.libbox.** { *; }
-keep class go.** { *; }
-dontwarn io.nekohasekai.libbox.**
-dontwarn go.**

# Keep our VPN service (referenced from AndroidManifest / system)
-keep class com.x4g.vpn.service.** { *; }

# Keep data models that get serialized
-keep class com.x4g.vpn.data.** { *; }

# Compose
-dontwarn androidx.compose.**

# General Kotlin metadata
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod
-keepclassmembers class kotlin.Metadata {
    public <methods>;
}
