package com.x4g.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.x4g.vpn.R
import com.x4g.vpn.core.PingChecker
import com.x4g.vpn.core.SingBoxController
import com.x4g.vpn.core.VlessConfigBuilder
import com.x4g.vpn.data.ConfigVault
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.data.VpnStateRepository
import com.x4g.vpn.ui.MainActivity
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.TunOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground [VpnService] responsible for the entire connection lifecycle:
 * parsing the embedded config, building the sing-box JSON, opening the TUN
 * interface, driving [SingBoxController], and keeping a persistent
 * notification alive while connected — mirroring how Hiddify Next / v2rayNG
 * style clients behave.
 */
class X4GVpnService : VpnService() {

    companion object {
        private const val TAG = "X4GVpnService"
        const val ACTION_CONNECT = "com.x4g.vpn.action.CONNECT"
        const val ACTION_DISCONNECT = "com.x4g.vpn.action.DISCONNECT"
        private const val NOTIFICATION_CHANNEL_ID = "x4g_vpn_status"
        private const val NOTIFICATION_ID = 1001
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunFd: ParcelFileDescriptor? = null
    private lateinit var singBoxController: SingBoxController
    private var pingJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        singBoxController = SingBoxController(this, platformInterface)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                disconnect()
                return START_NOT_STICKY
            }
            else -> {
                connect()
                return START_STICKY
            }
        }
    }

    private fun connect() {
        if (VpnStateRepository.uiState.value.connectionState == ConnectionState.CONNECTED) return

        VpnStateRepository.update { it.copy(connectionState = ConnectionState.CONNECTING, errorMessage = null) }
        startForeground(NOTIFICATION_ID, buildNotification(connecting = true))

        serviceScope.launch {
            try {
                val rawConfig = ConfigVault.reveal()
                val parsed = VlessConfigBuilder.parse(rawConfig)
                val configJson = VlessConfigBuilder.buildSingBoxConfig(parsed)

                singBoxController.start(configJson)

                VpnStateRepository.update {
                    it.copy(
                        connectionState = ConnectionState.CONNECTED,
                        connectedSinceMillis = System.currentTimeMillis()
                    )
                }
                updateNotification(connecting = false)
                startPingLoop(parsed.address, parsed.port)
            } catch (e: Exception) {
                Log.e(TAG, "connect failed", e)
                VpnStateRepository.update {
                    it.copy(
                        connectionState = ConnectionState.DISCONNECTED,
                        errorMessage = getString(R.string.connection_error_generic)
                    )
                }
                stopSelfSafely()
            }
        }
    }

    private fun disconnect() {
        VpnStateRepository.update { it.copy(connectionState = ConnectionState.DISCONNECTING) }
        pingJob?.cancel()
        serviceScope.launch {
            singBoxController.stop()
            closeTun()
            VpnStateRepository.reset()
            stopSelfSafely()
        }
    }

    private fun stopSelfSafely() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startPingLoop(host: String, port: Int) {
        pingJob?.cancel()
        pingJob = serviceScope.launch {
            while (true) {
                val ms = PingChecker.measureTcpHandshakeMs(host, port)
                VpnStateRepository.update { it.copy(pingMs = ms) }
                kotlinx.coroutines.delay(10_000)
            }
        }
    }

    private fun closeTun() {
        try {
            tunFd?.close()
        } catch (e: Exception) {
            Log.w(TAG, "error closing tun: ${e.message}")
        } finally {
            tunFd = null
        }
    }

    // ---- PlatformInterface: bridges libbox <-> Android VpnService APIs ----
    private val platformInterface = object : PlatformInterface {

        override fun openTun(options: TunOptions): Int {
            val builder = Builder()
                .setSession("X4G VPN")
                .setMtu(options.mtu.takeIf { it > 0 } ?: 9000)

            builder.addAddress("172.19.0.1", 28)
            builder.addDnsServer("1.1.1.1")
            builder.addDnsServer("1.0.0.1")
            builder.addRoute("0.0.0.0", 0)
            builder.addRoute("::", 0)

            val pfd = builder.establish() ?: error("VpnService.Builder#establish() returned null")
            tunFd = pfd
            return pfd.fd
        }

        override fun useProcFs(): Boolean = false

        override fun findConnectionOwner(
            ipProto: Int,
            sourceAddress: String,
            sourcePort: Int,
            destinationAddress: String,
            destinationPort: Int
        ): Int = -1

        override fun packageNameByUid(uid: Int): String = ""

        override fun uidByPackageName(packageName: String): Int = -1

        override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

        override fun autoDetectInterfaceControl(fd: Int) {
            protect(fd)
        }

        override fun underNetworkExtension(): Boolean = false

        override fun includeAllNetworks(): Boolean = false

        override fun clearDNSCache() { /* no-op: system handles this on Android */ }

        override fun readWIFIState(): io.nekohasekai.libbox.WIFIState? = null

        override fun systemCertificates(): io.nekohasekai.libbox.StringIterator? = null

        override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { /* handled by auto_detect_interface */ }

        override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { /* no-op */ }

        override fun getInterfaces(): NetworkInterfaceIterator? = null

        override fun usePlatformDefaultInterfaceMonitor(): Boolean = true

        override fun usePlatformInterfaceGetter(): Boolean = false
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(connecting: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, X4GVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (connecting) getString(R.string.notification_title_connecting)
        else getString(R.string.notification_title_connected)

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(getString(R.string.notification_text_tap))
            .setContentIntent(contentPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, getString(R.string.status_disconnecting), disconnectPendingIntent)
            .build()
    }

    private fun updateNotification(connecting: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(connecting))
    }

    override fun onDestroy() {
        pingJob?.cancel()
        closeTun()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onRevoke() {
        disconnect()
        super.onRevoke()
    }
}
