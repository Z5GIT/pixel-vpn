package com.x4g.vpn.core

import android.content.Context
import android.util.Log
import io.nekohasekai.libbox.BoxService
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.PlatformInterface
import java.io.File

/**
 * Thin Kotlin wrapper around the sing-box `libbox` Go Mobile bindings.
 *
 * `libbox` (produced from https://github.com/SagerNet/sing-box, package
 * `experimental/libbox`) exposes a `BoxService` object built from a JSON
 * config plus a `PlatformInterface` implementation that lets sing-box ask
 * the host app to create/protect the TUN file descriptor, resolve
 * interfaces, etc. The concrete `PlatformInterface` (VPN fd creation, DNS,
 * default-interface detection) is implemented in [X4GVpnService] since only
 * a `android.net.VpnService` subclass can establish the TUN device.
 *
 * This class only owns start/stop/status lifecycle of the underlying
 * `BoxService`; it holds no server details itself — those live in the JSON
 * config string it's handed by [VlessConfigBuilder].
 */
internal class SingBoxController(
    private val context: Context,
    private val platformInterface: PlatformInterface
) {
    companion object {
        private const val TAG = "SingBoxController"
    }

    private var boxService: BoxService? = null

    @Volatile
    var isRunning: Boolean = false
        private set

    /** Starts sing-box with the given full JSON configuration. */
    @Synchronized
    fun start(configJson: String) {
        if (isRunning) return

        // Base working directory for sing-box's internal cache/assets.
        val baseDir = File(context.filesDir, "singbox").apply { mkdirs() }
        val workingDir = File(context.filesDir, "singbox_work").apply { mkdirs() }

        Libbox.setup(
            /* basePath = */ baseDir.absolutePath,
            /* workingPath = */ workingDir.absolutePath,
            /* tempPath = */ context.cacheDir.absolutePath,
            /* isTVOS = */ false
        )

        val service = Libbox.newService(configJson, platformInterface)
        service.start()
        boxService = service
        isRunning = true
        Log.i(TAG, "sing-box started")
    }

    @Synchronized
    fun stop() {
        try {
            boxService?.close()
        } catch (e: Exception) {
            Log.w(TAG, "error stopping sing-box: ${e.message}")
        } finally {
            boxService = null
            isRunning = false
            Log.i(TAG, "sing-box stopped")
        }
    }
}
