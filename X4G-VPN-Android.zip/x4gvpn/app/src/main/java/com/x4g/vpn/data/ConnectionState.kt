package com.x4g.vpn.data

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    DISCONNECTING
}

data class VpnUiState(
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val pingMs: Int? = null,
    val serverLabel: String = "سرور بهینه",
    val errorMessage: String? = null,
    val connectedSinceMillis: Long? = null
)
