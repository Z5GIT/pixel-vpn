package com.x4g.vpn.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.ui.theme.AccentGreen
import com.x4g.vpn.ui.theme.AccentGreenSoft
import com.x4g.vpn.ui.theme.SurfaceElevated2
import com.x4g.vpn.ui.theme.TextTertiary

@Composable
fun ConnectButton(
    state: ConnectionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val connected = state == ConnectionState.CONNECTED
    val busy = state == ConnectionState.CONNECTING || state == ConnectionState.DISCONNECTING

    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringRotation"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val ringBrush = Brush.sweepGradient(
        colors = if (connected) {
            listOf(AccentGreen, AccentGreenSoft, Color.Transparent, AccentGreen)
        } else {
            listOf(TextTertiary.copy(alpha = 0.3f), Color.Transparent, TextTertiary.copy(alpha = 0.15f))
        }
    )

    Box(
        modifier = modifier.size(232.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer rotating ring — only visually "alive" while connected or connecting
        Box(
            modifier = Modifier
                .size(232.dp)
                .rotate(if (connected || busy) ringRotation else 0f)
                .background(brush = ringBrush, shape = CircleShape)
        )

        // Inner static backdrop to create ring thickness
        Box(
            modifier = Modifier
                .size(208.dp)
                .background(MaterialTheme.colorScheme.background, CircleShape)
        )

        // Main button surface
        Box(
            modifier = Modifier
                .size(188.dp)
                .scale(if (connected) pulse else 1f)
                .background(
                    brush = Brush.radialGradient(
                        colors = if (connected)
                            listOf(AccentGreenSoft, SurfaceElevated2)
                        else
                            listOf(SurfaceElevated2, MaterialTheme.colorScheme.surface)
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    enabled = !busy,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            if (busy) {
                CircularProgressIndicator(
                    color = AccentGreen,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(48.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Rounded.PowerSettingsNew,
                    contentDescription = null,
                    tint = if (connected) Color.White else TextTertiary,
                    modifier = Modifier.size(64.dp)
                )
            }
        }
    }
}
