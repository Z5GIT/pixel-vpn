package com.x4g.vpn.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.data.VpnStateRepository
import com.x4g.vpn.data.VpnUiState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class MainViewModel : ViewModel() {

    val uiState: StateFlow<VpnUiState> = VpnStateRepository.uiState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = VpnUiState()
    )

    fun isBusy(state: ConnectionState): Boolean =
        state == ConnectionState.CONNECTING || state == ConnectionState.DISCONNECTING
}
