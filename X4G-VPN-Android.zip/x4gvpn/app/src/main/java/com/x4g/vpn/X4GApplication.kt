package com.x4g.vpn

import android.app.Application

class X4GApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
