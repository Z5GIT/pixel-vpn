package com.x4g.vpn.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.x4g.vpn.R
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.ui.theme.AccentGreen
import com.x4g.vpn.ui.theme.AccentRed
import com.x4g.vpn.ui.theme.AccentAmber
import com.x4g.vpn.ui.theme.SurfaceElevated
import com.x4g.vpn.ui.theme.TextSecondary

@Composable
fun StatusLabel(state: ConnectionState) {
    val (text, color) = when (state) {
        ConnectionState.CONNECTED -> stringResource(R.string.status_connected) to AccentGreen
        ConnectionState.CONNECTING -> stringResource(R.string.status_connecting) to AccentAmber
        ConnectionState.DISCONNECTING -> stringResource(R.string.status_disconnecting) to AccentAmber
        ConnectionState.DISCONNECTED -> stringResource(R.string.status_disconnected) to TextSecondary
    }

    val infiniteTransition = rememberInfiniteTransition(label = "dot")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "dotAlpha"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            color = color,
            alpha = if (state == ConnectionState.CONNECTING || state == ConnectionState.DISCONNECTING) alpha else 1f
        )
        androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            color = color
        )
    }
}

@Composable
private fun Box(color: Color, alpha: Float) {
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .size(10.dp)
            .background(color.copy(alpha = alpha), CircleShape)
    )
}

@Composable
fun InfoCard(
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceElevated, RoundedCornerShape(20.dp))
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun MetricColumn(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary
        )
        androidx.compose.foundation.layout.Spacer(Modifier.size(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = if (valueColor == Color.Unspecified) MaterialTheme.colorScheme.onSurface else valueColor
        )
    }
}
