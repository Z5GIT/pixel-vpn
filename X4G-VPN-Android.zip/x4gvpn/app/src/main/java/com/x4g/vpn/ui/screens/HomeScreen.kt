package com.x4g.vpn.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.x4g.vpn.R
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.data.VpnUiState
import com.x4g.vpn.ui.theme.AccentGreen
import com.x4g.vpn.ui.theme.AccentRed
import com.x4g.vpn.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    uiState: VpnUiState,
    onToggleConnection: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(PaddingValues(horizontal = 24.dp, vertical = 32.dp)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BrandHeader()

            Spacer(Modifier.height(0.dp).weight(1f))

            StatusLabel(state = uiState.connectionState)

            Spacer(Modifier.height(28.dp))

            ConnectButton(
                state = uiState.connectionState,
                onClick = onToggleConnection
            )

            Spacer(Modifier.height(20.dp))

            AnimatedContent(
                targetState = uiState.connectionState,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "hint"
            ) { state ->
                Text(
                    text = when (state) {
                        ConnectionState.CONNECTED -> stringResource(R.string.tap_to_disconnect)
                        ConnectionState.DISCONNECTED -> stringResource(R.string.tap_to_connect)
                        ConnectionState.CONNECTING -> stringResource(R.string.status_connecting)
                        ConnectionState.DISCONNECTING -> stringResource(R.string.status_disconnecting)
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            Spacer(Modifier.height(0.dp).weight(1f))

            uiState.errorMessage?.let { error ->
                Text(
                    text = error,
                    color = AccentRed,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            InfoCard(modifier = Modifier.fillMaxWidth()) {
                MetricColumn(
                    label = stringResource(R.string.server_label),
                    value = uiState.serverLabel
                )
                MetricColumn(
                    label = stringResource(R.string.ping_label),
                    value = pingText(uiState),
                    valueColor = pingColor(uiState)
                )
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}

@Composable
private fun pingText(uiState: VpnUiState): String {
    return when {
        uiState.connectionState != ConnectionState.CONNECTED -> stringResource(R.string.ping_unavailable)
        uiState.pingMs == null -> stringResource(R.string.ping_measuring)
        else -> "${uiState.pingMs} ms"
    }
}

@Composable
private fun pingColor(uiState: VpnUiState) =
    if (uiState.connectionState == ConnectionState.CONNECTED && uiState.pingMs != null) AccentGreen
    else TextSecondary
