package com.x4g.vpn.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette — dark, professional, single accent
val BackgroundDeep = Color(0xFF0B0D12)
val SurfaceElevated = Color(0xFF141824)
val SurfaceElevated2 = Color(0xFF1B2130)
val AccentGreen = Color(0xFF3DDC97)
val AccentGreenSoft = Color(0xFF2AA876)
val AccentRed = Color(0xFFFF5C6C)
val AccentAmber = Color(0xFFFFC24B)
val TextPrimary = Color(0xFFF2F4F8)
val TextSecondary = Color(0xFF8A92A6)
val TextTertiary = Color(0xFF5C6479)
val DividerColor = Color(0xFF232838)
