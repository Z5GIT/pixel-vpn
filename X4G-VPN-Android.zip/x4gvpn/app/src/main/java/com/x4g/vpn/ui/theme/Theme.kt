package com.x4g.vpn.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val X4GDarkColorScheme = darkColorScheme(
    primary = AccentGreen,
    onPrimary = BackgroundDeep,
    secondary = AccentGreenSoft,
    background = BackgroundDeep,
    onBackground = TextPrimary,
    surface = SurfaceElevated,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated2,
    onSurfaceVariant = TextSecondary,
    error = AccentRed,
    outline = DividerColor
)

/**
 * X4G VPN always renders in dark mode, matching the aesthetic of
 * professional VPN clients (Hiddify Next, NekoBox, etc.) regardless of the
 * system theme — this is an explicit product decision, not a bug.
 */
@Composable
fun X4GVpnTheme(content: @Composable () -> Unit) {
    val colorScheme = X4GDarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = X4GTypography,
        content = content
    )
}
