package com.x4g.vpn.ui

import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import com.x4g.vpn.data.ConnectionState
import com.x4g.vpn.service.X4GVpnService
import com.x4g.vpn.ui.screens.HomeScreen
import com.x4g.vpn.ui.theme.X4GVpnTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startVpnService()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* granted or not — proceed either way, notification is best-effort */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            X4GVpnTheme {
                val uiState by viewModel.uiState.collectAsState()

                HomeScreen(
                    uiState = uiState,
                    onToggleConnection = {
                        when (uiState.connectionState) {
                            ConnectionState.DISCONNECTED -> requestConnect()
                            ConnectionState.CONNECTED -> disconnect()
                            else -> { /* ignore taps while connecting/disconnecting */ }
                        }
                    }
                )
            }
        }

        ensureNotificationPermission()
    }

    private fun requestConnect() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            startVpnService()
        }
    }

    private fun startVpnService() {
        val intent = Intent(this, X4GVpnService::class.java).apply {
            action = X4GVpnService.ACTION_CONNECT
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun disconnect() {
        val intent = Intent(this, X4GVpnService::class.java).apply {
            action = X4GVpnService.ACTION_DISCONNECT
        }
        startService(intent)
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
