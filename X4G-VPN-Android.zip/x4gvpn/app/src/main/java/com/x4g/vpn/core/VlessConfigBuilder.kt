package com.x4g.vpn.core

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Parses a `vless://` URI (as produced by most panels: Marzban, X-UI, etc.)
 * and builds a complete sing-box JSON configuration around it.
 *
 * The parsed fields (UUID, host, port, path...) live only in memory for the
 * duration of building this JSON — they are never written to logs, never
 * bound to any UI state, and never persisted outside the encrypted
 * [com.x4g.vpn.data.ConfigVault] payload they came from.
 */
internal data class ParsedVlessConfig(
    val uuid: String,
    val address: String,
    val port: Int,
    val encryption: String,
    val security: String,
    val type: String,
    val host: String,
    val path: String,
    val sni: String,
    val fingerprint: String,
    val alpn: List<String>,
    val remark: String
)

internal object VlessConfigBuilder {

    fun parse(uri: String): ParsedVlessConfig {
        val parsed = Uri.parse(uri)
        require(parsed.scheme == "vless") { "Unsupported scheme" }

        val uuid = parsed.userInfo ?: error("Missing UUID in config")
        val address = parsed.host ?: error("Missing host in config")
        val port = if (parsed.port != -1) parsed.port else 443

        fun q(name: String, default: String = "") = parsed.getQueryParameter(name) ?: default

        val alpnRaw = q("alpn", "h2,http/1.1")
        val alpnList = alpnRaw.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        return ParsedVlessConfig(
            uuid = uuid,
            address = address,
            port = port,
            encryption = q("encryption", "none"),
            security = q("security", "tls"),
            type = q("type", "tcp"),
            host = q("host", address),
            path = q("path", "/"),
            sni = q("sni", address),
            fingerprint = q("fp", "chrome"),
            alpn = alpnList,
            remark = parsed.fragment ?: "X4G"
        )
    }

    /**
     * Builds a full sing-box configuration (tun inbound + vless outbound with
     * WebSocket transport + TLS) as a JSON string ready to hand to libbox.
     *
     * @param socksPort local port sing-box exposes for internal health/ping checks
     */
    fun buildSingBoxConfig(cfg: ParsedVlessConfig, mtu: Int = 9000): String {
        val root = JSONObject()

        // ---- log ----
        root.put("log", JSONObject().apply {
            put("level", "warn")
            put("timestamp", true)
        })

        // ---- dns ----
        root.put("dns", JSONObject().apply {
            put("servers", JSONArray().apply {
                put(JSONObject().apply {
                    put("tag", "dns-remote")
                    put("address", "tls://1.1.1.1")
                    put("detour", "proxy")
                })
                put(JSONObject().apply {
                    put("tag", "dns-direct")
                    put("address", "1.1.1.1")
                    put("detour", "direct")
                })
            })
            put("strategy", "prefer_ipv4")
        })

        // ---- inbounds ----
        val tunInbound = JSONObject().apply {
            put("type", "tun")
            put("tag", "tun-in")
            put("interface_name", "x4g-tun")
            put("inet4_address", "172.19.0.1/28")
            put("mtu", mtu)
            put("auto_route", true)
            put("strict_route", true)
            put("stack", "system")
            put("sniff", true)
        }

        val mixedInbound = JSONObject().apply {
            put("type", "mixed")
            put("tag", "mixed-in")
            put("listen", "127.0.0.1")
            put("listen_port", 2334)
        }

        root.put("inbounds", JSONArray().apply {
            put(tunInbound)
            put(mixedInbound)
        })

        // ---- outbounds ----
        val tlsObj = JSONObject().apply {
            put("enabled", cfg.security == "tls" || cfg.security == "reality")
            put("server_name", cfg.sni)
            put("insecure", false)
            if (cfg.alpn.isNotEmpty()) put("alpn", JSONArray(cfg.alpn))
            put("utls", JSONObject().apply {
                put("enabled", true)
                put("fingerprint", cfg.fingerprint.ifBlank { "chrome" })
            })
        }

        val transportObj = JSONObject().apply {
            put("type", cfg.type.ifBlank { "tcp" })
            if (cfg.type == "ws") {
                put("path", cfg.path.ifBlank { "/" })
                put("headers", JSONObject().apply {
                    put("Host", cfg.host)
                })
            }
        }

        val vlessOutbound = JSONObject().apply {
            put("type", "vless")
            put("tag", "proxy")
            put("server", cfg.address)
            put("server_port", cfg.port)
            put("uuid", cfg.uuid)
            put("packet_encoding", "xudp")
            if (cfg.encryption.isNotBlank() && cfg.encryption != "none") {
                put("encryption", cfg.encryption)
            }
            put("tls", tlsObj)
            put("transport", transportObj)
        }

        val directOutbound = JSONObject().apply {
            put("type", "direct")
            put("tag", "direct")
        }

        val blockOutbound = JSONObject().apply {
            put("type", "block")
            put("tag", "block")
        }

        val dnsOutbound = JSONObject().apply {
            put("type", "dns")
            put("tag", "dns-out")
        }

        root.put("outbounds", JSONArray().apply {
            put(vlessOutbound)
            put(directOutbound)
            put(blockOutbound)
            put(dnsOutbound)
        })

        // ---- route ----
        root.put("route", JSONObject().apply {
            put("auto_detect_interface", true)
            put("final", "proxy")
            put("rules", JSONArray().apply {
                put(JSONObject().apply {
                    put("protocol", "dns")
                    put("outbound", "dns-out")
                })
            })
        })

        return root.toString()
    }
}
