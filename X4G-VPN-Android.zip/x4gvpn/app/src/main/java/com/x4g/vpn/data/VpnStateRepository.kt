package com.x4g.vpn.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide singleton holding the current VPN state. The foreground
 * service updates it; Compose UI collects it. Kept intentionally free of
 * any server/config detail — only connection status, ping, and a generic
 * "سرور بهینه" (optimal server) label are ever exposed here.
 */
object VpnStateRepository {

    private val _uiState = MutableStateFlow(VpnUiState())
    val uiState: StateFlow<VpnUiState> = _uiState.asStateFlow()

    fun update(transform: (VpnUiState) -> VpnUiState) {
        _uiState.value = transform(_uiState.value)
    }

    fun reset() {
        _uiState.value = VpnUiState()
    }
}
