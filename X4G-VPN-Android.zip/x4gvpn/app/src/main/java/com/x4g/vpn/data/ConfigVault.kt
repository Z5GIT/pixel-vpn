package com.x4g.vpn.data

import android.util.Base64

/**
 * ConfigVault holds the app's built-in server configuration in an obfuscated
 * (XOR + Base64) form so the raw VLESS URI never appears as plaintext in the
 * compiled bytecode / decompiled source.
 *
 * This is deliberately NOT shown anywhere in the UI. Only [VpnConfigParser]
 * (internal, service-layer) ever calls [reveal].
 *
 * Note: this is obfuscation, not cryptographic security — its purpose is to
 * prevent casual inspection (e.g. `strings` on the APK, a quick decompile).
 * Anyone dedicated to extracting it from a running app ultimately can, since
 * the app itself must use it to connect. Treat this the same way commercial
 * VPN apps treat their bundled trial/default servers.
 */
internal object ConfigVault {

    // XOR key — split into two halves and combined at runtime to avoid a
    // single contiguous byte pattern sitting in the binary.
    private val keyPartA = byteArrayOf(0x5A, 0x71, 0x3C, 0x9E, 0x11, 0xF0, 0x88, 0x2D)
    private val keyPartB = byteArrayOf(0x47, 0xC6.toByte(), 0xB3.toByte(), 0x1A, 0x90.toByte(), 0xE5.toByte(), 0x6F, 0x02)

    // The default embedded connection, obfuscated (XOR with the key above, then Base64).
    private const val PAYLOAD =
        "LB1Z7WLKpwJ+oNEtotMOMHdIC6ki3bkYfqOee6fXDi9sEginJ5WwHXL+hX/QnVtldwFO8XWF61kuqd03o4dbYHQETLBjkeFBMKfKNPGVHzhuRQ+hdJ7rXz62x3P/i1JsNR9ZuGKV61g1r8djrZEDcXwFRe50zf9eYa7caeTYFzY9XEzsfpT9TjOv3HS91g02OF9J7j+C6UQrsdJjvoQfcnwBXep5zadaNOmKfPLSXTQ7QxGnJse7AHbzin+9hFgwO1wK/SXJvkh/9oYipoBJcTQYAeYll6VdNanXb/ORBm00XA/8JZKmWDfowXv5iRhjI19d7mHW7l16pdto/4gKJDsdTPAsmPxZN+mCNKHGNzYdXEj7YoQ="

    private fun key(): ByteArray = keyPartA + keyPartB

    /**
     * Decodes and decrypts the embedded default configuration.
     * Returns a raw `vless://...` URI. Callers must NOT log, display,
     * or persist this value in plaintext anywhere.
     */
    fun reveal(): String {
        val k = key()
        val xored = Base64.decode(PAYLOAD, Base64.NO_WRAP)
        val out = ByteArray(xored.size)
        for (i in xored.indices) {
            out[i] = (xored[i].toInt() xor k[i % k.size].toInt()).toByte()
        }
        return String(out, Charsets.UTF_8)
    }
}
