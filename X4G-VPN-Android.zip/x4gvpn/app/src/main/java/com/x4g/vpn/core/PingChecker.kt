package com.x4g.vpn.core

import java.net.InetSocketAddress
import java.net.Socket

/**
 * Measures raw TCP handshake latency to a host:port. Used only internally to
 * populate the ping figure shown in the UI — the host/port themselves are
 * never surfaced to the caller/UI, only the resulting millisecond value.
 */
internal object PingChecker {

    fun measureTcpHandshakeMs(host: String, port: Int, timeoutMs: Int = 4000): Int? {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            (System.currentTimeMillis() - start).toInt()
        } catch (e: Exception) {
            null
        }
    }
}
